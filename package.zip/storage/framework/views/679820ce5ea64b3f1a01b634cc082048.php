<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <?php echo $__env->make('admin.css', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <style type="text/css">

      .div_center {
        text-align: center;
        padding-top: 40px;
      }

      .h2_font {
        font-size: 40px;
        padding-bottom: 40px;
      }

      .input_color {
        color: black;
      }

      .center {
        margin: auto;
        width: 50%;
        text-align: center;
        margin-top: 30px;
        border: 1px solid green;
      }
      

    </style>

  </head>
  
  <body>
    <div class="container-scroller">
      
      
      <!-- partial:partials/_sidebar.html -->
      <?php echo $__env->make('admin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <!-- partial -->
      <?php echo $__env->make('admin.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- partial -->

        <div class="main-panel">
          <div class="content-wrapper">

          <?php if(session()->has('message')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <?php echo e(session()->get('message')); ?>

              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
          <?php endif; ?>

          <div class="div_center">

              <h2 class="h2_font">Add Category</h2>

              <form action="<?php echo e(url('/add_category')); ?>" method="POST">

                <?php echo csrf_field(); ?>

                <input type="text" class="input_color" name="category" placeholder="Write Category Name">

                <input type="submit" class="btn btn-primary" name="submit" value="Add Category">
              </form>

          </div>

          <table class="center">

            <tr>
              <td>Category Name</td>
              <td>Action</td>
            </tr>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
              <td><?php echo e($data->category_name); ?></td>
              <td><a onclick="return confirm('Are You Sure To Delete This')" class="btn btn-danger" href="<?php echo e(url('delete_category',$data->id)); ?>">Delete</a></td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </table>

          </div>

        </div>
       
    <!-- container-scroller -->
    <!-- plugins:js -->
    <?php echo $__env->make('admin.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End custom js for this page -->
  </body>
</html><?php /**PATH C:\Afrinet\resources\views/admin/category.blade.php ENDPATH**/ ?>