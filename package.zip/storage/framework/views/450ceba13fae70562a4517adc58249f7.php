<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->

    <base href="/public">

    <?php echo $__env->make('admin.css', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <style type="text/css">

      label {
        display: inline-block;
        width: 200px;
        font-size: 15px;
        font-weight: bold;
        margin-top: 30px;
      }

    </style>
  </head>
  
  <body>
    <div class="container-scroller">


    
      
      
      <!-- partial:partials/_sidebar.html -->
      <?php echo $__env->make('admin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <!-- partial -->
      <?php echo $__env->make('admin.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- partial -->
      
    <!-- container-scroller -->
    <!-- plugins:js -->

    <div class="main-panel">
        <div class="content-wrapper">

        <h1 style="text-align: center; font-size: 25px;">Send Email to <?php echo e($order->email); ?></h1>
        
        <form action="<?php echo e(url('send_user_email',$order->id)); ?>" method="POST">

          <?php echo csrf_field(); ?>
          <div style="padding-left: 35%;">
            <label>Email Greetings : </label>

            <input style="color: black;" type="text" name="greeting">
          </div>

          <div style="padding-left: 35%;">
            <label>Email FirstLine : </label>

            <input style="color: black;" type="text" name="firstline">
          </div>

          <div style="padding-left: 35%;">
            <label>Email Body : </label>

            <input style="color: black;" type="text" name="body">
          </div>

          <div style="padding-left: 35%;">
            <label>Email Button Name : </label>

            <input style="color: black;" type="text" name="button">
          </div>

          <div style="padding-left: 35%;">
            <label>Email Url : </label>

            <input style="color: black;" type="text" name="url">
          </div>

          <div style="padding-left: 35%;">
            <label>Email Last Line : </label>

            <input style="color: black;" type="text" name="lastline">
          </div>

          <div style="padding-left: 35%;">

            <input style="color: black;" type="submit" value="Send Email" class="btn btn-primary">
          </div>
        </form>

        </div>
      </div>

    <?php echo $__env->make('admin.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End custom js for this page -->
  </body>
</html><?php /**PATH C:\Afrinet\resources\views/admin/email_info.blade.php ENDPATH**/ ?>